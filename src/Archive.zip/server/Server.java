package server;

public interface Server {
	void start();

	void stop();
}
